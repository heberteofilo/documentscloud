#!/bin/bash
sudo chown -R www-data:www-data /var/documents